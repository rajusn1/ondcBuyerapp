// routes/cartRoutes.js
const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
 const Product = require('../models/Product'); // Assuming you have a Product model

// Add item to cart
router.post('/add', async (req, res) => {
    try {
        const { userId, productId } = req.body;
        const cart = await Cart.findOne({ user: userId });

        if (!cart) {
            return res.status(404).json({ error: 'Cart not found' });
        }

        const product = await Product.findById(productId);
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }

        // Check if the product is already in the cart
        const existingItem = cart.items.find(item => item.product.equals(productId));

        if (existingItem) {
            existingItem.quantity++;
        } else {
            cart.items.push({ product: productId });
        }

        await cart.save();
        res.status(200).json({ message: 'Item added to cart successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Delete item from cart
router.delete('/delete', async (req, res) => {
    try {
        const { userId, productId } = req.body;
        const cart = await Cart.findOne({ user: userId });

        if (!cart) {
            return res.status(404).json({ error: 'Cart not found' });
        }

        // Remove the item from the cart
        cart.items = cart.items.filter(item => !item.product.equals(productId));
        await cart.save();
        res.status(200).json({ message: 'Item removed from cart successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Increase item quantity in cart
router.put('/increase', async (req, res) => {
    try {
        const { userId, productId } = req.body;
        const cart = await Cart.findOne({ user: userId });

        if (!cart) {
            return res.status(404).json({ error: 'Cart not found' });
        }

        const existingItem = cart.items.find(item => item.product.equals(productId));

        if (!existingItem) {
            return res.status(404).json({ error: 'Item not found in cart' });
        }

        existingItem.quantity++;
        await cart.save();
        res.status(200).json({ message: 'Item quantity increased in cart successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;
