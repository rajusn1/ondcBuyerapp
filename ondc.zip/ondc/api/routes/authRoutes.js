// routes/authRoutes.js
const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Registration Route
router.post('/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const user = new User({ username, email, password });
        await user.save();
        res.status(201).send({ message: 'User registered successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: 'Registration failed' });
    }
});

// Login Route
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email, password });
        if (!user) {
            return res.status(401).send({ error: 'Invalid email or password' });
        }
        // For simplicity, in a real-world scenario, you would use token-based authentication
        res.status(200).send({ message: 'Login successful' });
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: 'Login failed' });
    }
});

module.exports = router;

