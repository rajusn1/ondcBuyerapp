// server.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors'); // Import cors package
const User = require('./models/User');
const Cart = require('./models/Cart');
const Product = require('./models/Product');
const authRoutes = require('./routes/authRoutes');
const cartRoutes = require('./routes/cartsRoutes');
const productRoutes = require('./routes/productRoutes');
const app = express();
const PORT = process.env.PORT || 8000;

// MongoDB Atlas connection URI
const mongoURI = 'mongodb+srv://helpmuzimate:le0LjvgRPIV8PEUt@cluster0.jovidse.mongodb.net/?retryWrites=true&w=majority';

// Connect to MongoDB Atlas
mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log('Connected to MongoDB Atlas');
})
.catch(err => {
    console.error('Error connecting to MongoDB Atlas:', err);
});

// Use CORS middleware
app.use(express.json());
app.use(cors());
app.use('/auth', authRoutes);
app.use('/cart', cartRoutes);
app.use('/product', productRoutes);  

// Define routes
// Example:
// app.get('/', (req, res) => {
//     res.send('Hello World!');
// });

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
