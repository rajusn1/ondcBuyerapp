import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Button, Image, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import productsData from '../products.json';
const CartScreen = ({ navigation }) => {
  const [cartItems, setCartItems] = useState([
    { id: 1, quantity: 1 },
    { id: 2, quantity: 1 },
    // Add more items to cart as needed
  ]);


  const handleIncreaseQuantity = (item) => {
    const updatedCart = cartItems.map((cartItem) => {
      if (cartItem.id === item.id) {
        return { ...cartItem, quantity: cartItem.quantity + 1 };
      }
      return cartItem;
    });
    setCartItems(updatedCart);
  };
  const handleDecreaseQuantity = (item) => {
    const updatedCart = cartItems.map((cartItem) => {
      if (cartItem.id === item.id) {
        if (cartItem.quantity === 1) {
          // Remove the item from the cart if its quantity becomes 0
          return null;
        } else {
          return { ...cartItem, quantity: cartItem.quantity - 1 };
        }
      }
      return cartItem;
    }).filter(Boolean); // Filter out null items
    setCartItems(updatedCart);
    
  };
  

  const getItemTotalPrice = (item) => {
    const product = productsData.find((product) => product.id === item.id);
    return product.price * item.quantity;
  };

  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + getItemTotalPrice(item), 0);
  };

  const renderItem = ({ item }) => {
    const product = productsData.find((product) => product.id === item.id);
    return (
      <View style={styles.itemContainer}>
        <Image source={{ uri: product.image }} style={styles.itemImage} />
        <View style={styles.itemDetails}>
        <Text style={styles.itemName}>{product.productName}</Text>
        <Text >₹ {product.price.toFixed(2)}</Text>
        </View>
  
        {/* <Text style={styles.itemPrice}>₹ {product.price.toFixed(2)*item.quantity}</Text>
        <View style={styles.quantityContainer}>
          <Text style={styles.quantity}>{item.quantity}</Text>
          <Button title="+" onPress={() => handleIncreaseQuantity(item)} />
          &nbsp;
          <Button title="-" onPress={() => handleDecreaseQuantity(item)} />
        </View> */}
        <View style={styles.quantityContainer}>
        <Text style={styles.itemPrice}>₹ {product.price.toFixed(2)*item.quantity}</Text>

        <Text style={styles.quantity}>{item.quantity}</Text>
        <View style={styles.quantityButtons}>
          <Button title="+" onPress={() => handleIncreaseQuantity(item)} />&nbsp;
          <Button title="-" onPress={() => handleDecreaseQuantity(item)} />
        </View>
      </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cart</Text>
      <FlatList
        data={cartItems}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
      <Text style={styles.totalPrice}>Total Price: ₹ {getTotalPrice().toFixed(2)}</Text>
      <Button title="Proceed to Checkout" onPress={() => navigation.navigate('Checkout')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  itemImage: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  itemDetails: {
    flex: 1,
  },
  itemName: {
    fontSize: 18,
    marginBottom: 5,
  },
  itemPrice: {
    fontSize: 16,
    color: '#000',
    padding:5,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantity: {
    fontSize: 18,
    marginRight: 10,
  },
  quantityButtons: {
    flexDirection: 'row',
    marginRight: 10,
  },
  totalPrice: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default CartScreen;
