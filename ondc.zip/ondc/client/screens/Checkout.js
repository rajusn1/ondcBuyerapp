import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';

const CheckoutPage = () => {
  const [shippingAddress, setShippingAddress] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [orderNotes, setOrderNotes] = useState('');

  const handlePlaceOrder = () => {
    // Implement place order functionality
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.innerContainer}>
        <Text style={styles.heading}>Checkout</Text>
        
        {/* Order Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionHeading}>Order Summary:</Text>
          {/* Render order summary items dynamically */}
          {/* For simplicity, assuming static data */}
          <View>
            <Text>Soft Drink</Text>
            <Text>Namkeen</Text>
            {/* Add more items */}
          </View>
          <Text style={styles.total}>Total: ₹80.00</Text>
        </View>
        
        {/* Shipping Information */}
        <View style={styles.section}>
          <Text style={styles.sectionHeading}>Shipping Information:</Text>
          <TextInput
            placeholder="Shipping Address"
            value={shippingAddress}
            onChangeText={setShippingAddress}
            style={styles.input}
          />
          {/* Add shipping method selection */}
          {/* Add estimated delivery */}
        </View>
        
        {/* Payment Information */}
        <View style={styles.section}>
          <Text style={styles.sectionHeading}>Payment Information:</Text>
          {/* Payment method selection */}
          <TextInput
            placeholder="Card Number"
            value={cardNumber}
            onChangeText={setCardNumber}
            style={styles.input}
          />
          {/* Add more input fields for expiry date and CVV */}
        </View>
        
        {/* Order Notes */}
        <View style={styles.section}>
          <Text style={styles.sectionHeading}>Order Notes:</Text>
          <TextInput
            placeholder="Add any additional notes..."
            value={orderNotes}
            onChangeText={setOrderNotes}
            multiline
            style={[styles.input, { height: 100 }]}
          />
        </View>
        
        {/* Place Order Button */}
        <TouchableOpacity onPress={handlePlaceOrder} style={styles.button}>
          <Text style={styles.buttonText}>Place Order</Text>
        </TouchableOpacity>
        
        {/* Security Assurance */}
        {/* Contact Information */}
        {/* Order Confirmation */}
        {/* Optional: Promo Code */}
        {/* Trust Signals */}
        {/* Return Policy */}
        {/* Order Tracking */}
        {/* Add these sections */}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  innerContainer: {
    padding: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionHeading: {
    fontSize: 18,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  total: {
    fontWeight: 'bold',
    marginTop: 10,
  },
  button: {
    backgroundColor: 'blue',
    padding: 15,
    alignItems: 'center',
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
});

export default CheckoutPage;
