import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Button, Image, StyleSheet, Dimensions } from 'react-native';
import productsData from '../products.json';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createStackNavigator } from '@react-navigation/stack';
import { TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
const ProductScreen = ({ navigation }) => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    setProducts(productsData);
  }, []);

  const handleAddToCart = async (product) => {
    try {
      // Get existing cart items from local storage
      const existingCartItems = await AsyncStorage.getItem('cartItems');
      let cartItems = [];
  
      if (existingCartItems) {
        // Parse existing cart items from JSON
        cartItems = JSON.parse(existingCartItems);
      }
  
      // Add the ID of the selected product to the cart items
      cartItems.push(product.id);
  
      // Save updated cart items to local storage
      await AsyncStorage.setItem('cartItems', JSON.stringify(cartItems));
  
      alert(`Added ${product.productName} to the cart!`);
    } catch (error) {
      console.error('Error adding product to cart:', error);
    }
  };

  const numColumns = 2; // Number of columns in the grid
  const itemMargin = 10; // Margin between products

  const renderProductItem = ({ item }) => (
    
    <View style={[styles.productContainer, { marginRight: itemMargin }]}>
    
      <Image source={{ uri: item.image }} style={styles.productImage} />
      <Text style={styles.productName}>{item.productName}</Text>
      <Text style={styles.productPrice}>₹ {item.price.toFixed(2)}</Text>
      <Button
        title="Add to Cart"
        onPress={() => handleAddToCart(item)}
        color="#3498db"
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Product List</Text>
        <Button title="Cart" onPress={() => navigation.navigate('Cart')} />
      </View>
      <FlatList
        data={products}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderProductItem}
        numColumns={numColumns}
        columnWrapperStyle={styles.columnWrapper}
        contentContainerStyle={styles.contentContainer}
      />
    </View>
  );
};

const windowWidth = Dimensions.get('window').width;
const columnWidth = windowWidth / 2 - 20 - 10; // Adjust margin

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  productContainer: {
    width: columnWidth,
    marginBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ecf0f1',
    paddingBottom: 10,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  productPrice: {
    fontSize: 16,
    color: '#2ecc71',
  },
  productImage: {
    width: '100%',
    height: 200,
    marginBottom: 10,
  },
  columnWrapper: {
    justifyContent: 'space-between',
  },
  contentContainer: {
    paddingBottom: 20, // Add padding at the bottom for margin
  },
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
  },
});

export default ProductScreen;
