import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './screens/Home';
import Checkout from './screens/Checkout';
import LoginScreen from './screens/Login';
import ProductScreen from './screens/ProductScreen';
import Register from './screens/Register';
import Cart from './screens/Cart';

const Stack = createStackNavigator();

function App() {
  const logged = false;
  const initialRouteName = logged ? 'Product' : 'Home';
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={initialRouteName}>
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Product" component={ProductScreen} />
        <Stack.Screen name="Register" component={Register} />
        <Stack.Screen name="Cart" component={Cart} />
        <Stack.Screen name="Checkout" component={Checkout} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
